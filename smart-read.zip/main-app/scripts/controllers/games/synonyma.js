mainApp.controller('SynonymaCtrl', function ($scope, $route, $rootScope, $http, $modal, $route, $location, lookupService, imageSearchService, $timeout, user) {



});