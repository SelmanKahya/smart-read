mainApp.controller('WordLookupQuizOnlineCtrl', function ($scope, $route, $rootScope, $http, $modal, $route, $location, lookupService, imageSearchService, $timeout, user) {



});