'use strict';

var options = angular.module('service.socket', []);

options.factory('socket', function() {
    return {

    }
});