Readium.Utils.isIOS = function() {
	return  !!navigator.userAgent.match(/iPad|iPhone|iPod/);
};